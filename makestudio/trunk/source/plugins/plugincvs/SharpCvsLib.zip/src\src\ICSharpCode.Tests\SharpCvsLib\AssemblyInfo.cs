using System;
using System.Reflection;
//using System.EnterpriseServices;
using System.Runtime.InteropServices;

[assembly: ComVisibleAttribute(false)]
[assembly: CLSCompliantAttribute(false)]
[assembly: AssemblyVersionAttribute("0.0.0.0")]
[assembly: AssemblyTitleAttribute("Concurrent Versions System (sharpCVS) (client)")]
[assembly: AssemblyCopyrightAttribute("Mike Krueger 2001-2002, SharpCvsLib Developers 2003-2004\r\n\r\nCVS may be copied onl" +
"y under the terms of the GNU General Public License,\r\na copy of which can be fou" +
"nd with the CVS distribution kit.")]
[assembly: AssemblyCompanyAttribute("SharpCvsLib - http://sharpcvslib.sourceforge.net")]
//[assembly: ApplicationNameAttribute("SharpCvsLib")]
